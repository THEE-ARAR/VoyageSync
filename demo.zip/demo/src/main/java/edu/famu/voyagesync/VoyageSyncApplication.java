package edu.famu.voyagesync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoyageSyncApplication {

    public static void main(String[] args) {
        SpringApplication.run(VoyageSyncApplication.class, args);
    }

}
