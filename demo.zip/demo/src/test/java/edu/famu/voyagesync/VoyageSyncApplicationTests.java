package edu.famu.voyagesync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoyageSyncApplicationTests {

    @Test
    void contextLoads() {
    }

}
